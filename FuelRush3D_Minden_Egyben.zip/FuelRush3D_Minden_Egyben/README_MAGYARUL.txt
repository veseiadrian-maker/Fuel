FUEL RUSH 3D – MINDEN EGYBEN

EZ A FŐ JÁTÉKFÁJL: index.html
A legutóbbi böngészős verzióban benne van az eddig összeállított játékfunkciók legújabb változata:
- 3D-s autóvezetés, szabad érintős kormányzás
- forgalom, akadályok, üzemanyag és ritka üzemanyagkannák
- normál érmék és ritkább prémium érmék
- garázs, 6 választható fantáziaautó és mérföldköves feloldás
- autófejlesztések és mentett fejlődés
- külső tuning: fényezés, felnik, versenycsíkok, spoiler és neon
- forgatható autó-előnézet a garázsban

IPHONE / ANDROID BÖNGÉSZŐS INDÍTÁS:
1. A teljes mappát tartsd egyben; az index.html legyen a feltöltött webmappa gyökerében.
2. A mappát statikus webtárhelyre kell feltölteni (pl. Netlify Drop, ha a fiók hozzáférése működik).
3. A kapott webcímet Safariban (iPhone) vagy Chrome-ban (Android) nyisd meg.
4. iPhone-on Safari > Megosztás > Főképernyőhöz adás.

FONTOS:
- Az index.html Three.js-t tölt be a jsDelivr CDN-ről, tehát internetkapcsolat kell.
- A játék mentése az adott böngésző helyi tárhelyére kerül; másik eszközön nem szinkronizál automatikusan.
- Ez böngészős prototípus, nem natív App Store alkalmazás.
- A Netlify-ra még nincs feltöltve, és a teljes működést valódi eszközön újra kell tesztelni.

TOVÁBBI CSOMAGOK:
- Android_projekt.zip: Android WebView projekt és GitHub Actions build konfiguráció; nem kész APK.
- Korabbi_verziok.zip: az eddigi külön kiadások archivált ZIP-jei.
